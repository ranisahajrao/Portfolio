import React from 'react';
import './About.css';

const AboutMe = () => {
  return (
    <section id="about" className="about">
      <div className="container">
        <h2>About Me</h2>
        <p>A position in a results-oriented company that seeks an ambitious and career-oriented professional...</p>
      </div>
    </section>
  );
};

export default AboutMe;
