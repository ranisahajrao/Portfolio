import React from 'react';
import './Project.css';

const Projects = () => {
  return (
    <section id="projects" className="projects">
      <div className="container">
        <h2>Projects</h2>
        <div className="project-item">
          <h3>Arina AI</h3>
          <p>AI-driven web platform offering multiple AI solutions...</p>
        </div>
      </div>
    </section>
  );
};

export default Projects;
