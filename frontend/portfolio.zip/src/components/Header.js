import React from 'react';
import './Header.css';

const Header = ({ toggleTheme }) => {
  return (
    <header className="header">
      <div className="container">
        <h1>Pradnya Sanghraj Sahajrao</h1>
        <p>Full Stack Developer</p>
        <button className="theme-toggle" onClick={toggleTheme}>Toggle Theme</button>
      </div>
    </header>
  );
};

export default Header;